<?php

$db = new PDO("mysql:host=localhost;dbname=membership;charset=utf8", "root", "");


$userName = $_POST['user_name'];
$mail = $_POST['mail'];
$password = $_POST['password'];

if(!$userName || !$mail || !$password){
	die("Please, don't leave null fields!");
}

$query = $db-> prepare("INSERT INTO users SET userName = ? , mail = ? , password = ?");
$query-> execute([$userName , $mail , $password]); 

if($query){
	header("location:login-page.php");
}else{
	echo "There is an error!";
}

?>