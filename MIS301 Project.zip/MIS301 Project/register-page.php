<!DOCTYPE html>
<html>
    <head>
        <title>REGISTER PAGE</title>
        <link rel="stylesheet" href="styleregister.css">
    </head>
    <body>
        
        <form action="signup.php" method="post">
            <label for="">USER NAME</label><br>
            <input type="text" name="user_name"><br>
    
            <label for="">MAIL</label><br>
            <input type="text" name="mail"><br>
    
            <label for="">PASSWORD</label><br>
            <input type="password" name="password"><br>
    
            <br>
            <button>REGISTER</button>
        </form>
    </body>
</html>