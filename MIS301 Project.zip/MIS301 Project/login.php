<?php 

session_start();

$db = new PDO("mysql:host=localhost;dbname=membership;charset=utf8","root", "");

$userName = $_POST['user_name'];
$password = $_POST['password'];

if(!$userName || !$password){
	die("Please, don't leave null fields!");
}

$user = $db-> query("SELECT * FROM users WHERE userNAme = '$userName' AND password = '$password'")->fetch();

if($user){
	$_SESSION['user'] = $user;
	header("location:index2.php");
}else{
	echo "Wrong Informatıons!";
}
?>