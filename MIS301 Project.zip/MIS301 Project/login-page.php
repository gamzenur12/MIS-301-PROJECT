
<!DOCTYPE html>
<html>
    <head>
        <title>LOG IN PAGE</title>
        <link rel="stylesheet" href="styleregister.css">
    </head>
    <body>
        <form action="login.php" method="post" class="form">
            <label for="">USER NAME</label><br>
            <input type="text" name="user_name"><br>
    
            <label for="">PASSWORD</label><br>
            <input type="password" name="password"><br>
    
            <br>
            <button>LOG IN</button>
            <button><a href="register-page.php" style="text-decoration: none;color: #000; font-weight: 700;">REGISTER</a>
            </button>
        </form>
    </body>
</html>