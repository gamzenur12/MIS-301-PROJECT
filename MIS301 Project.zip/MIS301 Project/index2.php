<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <mega name="keywords" content="Funny, fun, hobby, movies,series, digital rejoicing, learnbox, education, time evaluation, hiking, painting, best movies, best series, software courses, health courses" >
        <title>Main Page</title>

        <link href="https://fonts.googleapis.com/css2?family=Lora:wght@400;500;700&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="style.css" />
        <link href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" rel="stylesheet" />
    </head>
    <body>
        <header>
            <div class="image">
                <img src="images/icon.png" alt="logo" />
            </div>
            <div class="image-2">
                <img src="images/icon.png" alt="logo" />
            </div>
            <div class="container">
                <h1 style="color: darkviolet;">AmazingGorgeousGenius</h1>
                <hr class="moon" />
                <h2 style="color: mediumblue;">ABOUT US</h2>
                <p>
                    <b>
                        Don't you know how to your time? Do you get lost searching for what you want to do on the internet? This page is perfect you. When people make time for themselves, they create a free space for them to live. They
                        always take successful and confident steps with this sense of freedom. Save time losting on the internet with this page. Explore life with options in carefully crafted categories. If you want to see the world inside
                        you, you should explore this page.
                    </b>
                </p>
            </div>
            <div class="button" style="margin-right: 100px; float: right;">
                <form action="logout.php">
                    <button style="width: 68px; font-weight: 700;"><a href="index.php" style="color: #000; text-decoration: none;">LOG OUT</a></button>
                </form>
            </div>
        </header>
        <section>
            <div class="biggest">
                <div class="col">
                    <div class="gallery">
                        <a href="Hobby.html">
                            <img src="images/h.jpeg" alt="" />
                        </a>
                        <div class="title">
                            <b>HOBBY STREET</b>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="gallery">
                        <a href="digital.html">
                            <img src="images/d.jpeg" alt="" />
                        </a>
                        <div class="title">
                            <b>DIGITAL REJOICING</b>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="gallery">
                        <a href="learnbox.html">
                            <img src="images/l.jpeg" alt="" />
                        </a>
                        <div class="title">
                            <b>LEARN BOX</b>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <h2>Contact</h2>
            <hr class="moon" />
            <div class="contact-image" style="padding-left: 50px;">
                <img src="images/icon.png" alt="logo" />
            </div>
            <div class="contact-image-2" style="padding-right: 60px;">
                <img src="images/icon.png" alt="logo" />
            </div>
            <div>
                <div class="footeritem">
                    <h5><b>If you have an idea or question please contact us.</b></h5>
                    <p><i class="fas fa-envelope"></i> <a href="mailto:info@agg.com" style="color: #000000;"> info@agg.com</a></p>
                </div>

                <div class="footeritem">
                    <h5><b>Follow us on social media.</b></h5>
                    <ul>
                        <li>
                            <a href="" style="color: black;"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li>
                            <a href="" style="color: black;"><i class="fab fa-instagram"></i></a>
                        </li>
                        <li>
                            <a href="" style="color: black;"><i class="fab fa-facebook-f"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </body>
</html>
